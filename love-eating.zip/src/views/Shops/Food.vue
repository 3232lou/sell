<template>
<transition name="move">
  <div class="food" v-if="isShow">
    <div class="foodPanel-close" @click="$emit('close')">
      <i class="fa fa-close"></i>
    </div>
    <div class="foodPanel-body">
      <div class="foodPanel-foodimg">
        <img :src="food.image_path" alt="" />
      </div>
      <div class="foodPanel-foodInfo">
        <h4>{{ food.name }}</h4>
        <div class="foodPanel-foodSales">
          <span>月售{{ food.month_sales }}</span>
          <span>好评率 {{ food.satisfy_rate }}%</span>
        </div>
        <div class="foodPanel-priceLine">
          <span>¥{{ food.activity.fixed_price }}</span>
          <CartControll class="cart-btn" :food="food" />
        </div>
        <p>{{ food.description }}</p>
      </div>
    </div>
  </div>
  </transition>
</template>

<script>
import CartControll from '@/components/Shops/CartControll'
export default {
  name: "food",
  props: {
    food: Object,
    isShow:Boolean
  },
  components: {
    CartControll
  }
};
</script>

<style scoped>
.food {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 100;
}
.foodPanel-close {
  width: 7.466667vw;
  height: 7.466667vw;
  border-radius: 50%;
  background-color: rgba(0, 0, 0, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  z-index: 1;
  top: 2.133333vw;
  right: 4vw;
}
.foodPanel-close i {
  width: 5.333333vw;
  height: 5.333333vw;
  text-align: center;
}
.foodPanel-body{
  position: relative;
  background-color: #fff;
  display: flex;
   flex-direction: column;
  width: 100vw;
  height: 100vh;
  padding-bottom: 20vh;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: auto;
}
.foodPanel-foodimg {
  width: 100%;
}
.foodPanel-foodimg img {
  width: 100vw;
}
.foodPanel-foodInfo{
  padding: 4vw 4vw 0;
  width: 100%;
  min-height: 29.333333vw;
}
.foodPanel-foodInfo h4 {
  display: flex;
  align-items: center;
  margin-bottom: 2.4vw;
  font-size: 24px;
  font-weight: 700;
  width: 74.666667vw;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.foodPanel-foodSales{
  font-size: 24px;
  color: #666;
  line-height: 1;
  margin-bottom: 2.4vw;
}
.foodPanel-priceLine{
  display: flex;
  align-items: center;
  margin-bottom: 2.4vw;
  position: relative;

}
.foodPanel-priceLine > span {
  font-size: 1rem;
  line-height: 4.266667vw;
  color: #ff5339;
  padding-bottom: 0.933333vw;
  display: flex;
  align-items: baseline;
}
.foodPanel-priceLine .cart-btn {
  position: absolute;
  right: 8vw;
}
.foodpanel-foodinfo > p {
  font-size: 0.8rem;
  color: #666;
  line-height: 3.733333vw;
  padding-right: 8vw;
}
.move-enter-active,
.move-leave-active {
  transition: all 0.25s ease-in;
  transform: translate(0, -500px);
}

.move-enter,
.move-leave-to {
  transform: translate(0, 500px);
}
</style>

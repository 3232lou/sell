<template>
  <div class="shop" v-if="shopInfo">
    <!--头部-->
    <nav class="header-nav">
      <div class="nav_bg">
        <img :src="shopInfo.rst.scheme" alt="" />
      </div>
      <div class="nav_back">
        <i @click="$router.push('/home')" class="fa fa-chevron-left"></i>
      </div>
      <div class="shop_image">
        <img :src="shopInfo.rst.image_path" alt="" />
      </div>
    </nav>

    <!--商家信息-->
    <div class="index-rst">
      <div class="rst-name" @click="infoModelShow">
        <span>{{ shopInfo.rst.name }}</span>
        <i class="fa fa-caret-right"></i>
      </div>
      <!--弹窗信息-->
      <info-model
        @close="showInfoModel = false"
        :rst="shopInfo.rst"
        :showInfoModel="showInfoModel"
      >
      </info-model>

      <!--评分月售-->
      <div class="rst-order">
        <span>评分{{ shopInfo.rst.rating }}</span>
        <span>月售{{ shopInfo.rst.recent_order_num }}单</span>
        <span>蜂鸟送达{{ shopInfo.rst.order_lead_time }}分钟</span>
      </div>

      <!--优惠信息-->
      <activity :activities = 'shopInfo.rst.activities'></activity>
      <!--公告-->
      <p class="rst-promotion">公告：{{ shopInfo.rst.promotion_info }}</p>
    </div>

    <!--Nav导航-->
    <nav-bar></nav-bar>
   <keep-alive>
      <router-view></router-view>
   </keep-alive>
  </div>
</template>

<script>
import InfoModel from "../../components/Shops/InfoModel.vue";
import Activity from '@/components/Shops/Activity'
import NavBar from '@/components/Shops/NavBar'
export default {
  name: "shop",
  created() {
    this.getData();
  },
  methods: {
    getData() {
      this.axios("/api/profile/batch_shop").then(res => {
        this.shopInfo = res.data;
        console.log(this.shopInfo);
      });
    },
    infoModelShow() {
      this.showInfoModel = true;
    }
  },
  data() {
    return {
      shopInfo: null,
      showInfoModel: false
    };
  },
  components: {
    InfoModel,
    Activity,
    NavBar
  }
};
</script>

<style scoped>
.shop {
  width: 100%;
  height: 100%;
  box-sizing: border-box;

}
.header-nav {
  position: relative;
}
.nav_bg img {
  width: 100%;
  height: 288px;
}
.nav_back {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 50px;
  background: rgba(0, 0, 0, 0.5);
}
.nav_back i {
  color: #fff;
  font-size: 36px;
  margin-left: 1.333333vw;
  margin-top: 1.333333vw;
}
.shop_image {
  position: absolute;
  top: 0;
  left: 50%;
  margin-left: -10vw;
  margin-top: 105px;
}
.shop_image img {
  width: 120px;
  height: 120px;
  border-radius: 0.8vw;
}
.index-rst {
  display: flex;
  background: #fff;
  flex-direction: column;
  align-items: center;
  box-shadow: inset 0 -0.666667vw 0.666667vw hsla;
}
.index-rst .rst-name {
  flex: 1;
  width: 72vw;
  font-size: 24px;
  font-weight: 700;
  padding-right: 2.666667vw;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 1.6vw 0;
}
.rst-name span {
  text-align: left;
  overflow: hidden;
  text-overflow: ellipsis;
}
.index-rst .rst-order {
  white-space: nowrap;
  height: 3.2vw;
  margin-top: 1.733333vw;
  color: #666;
  text-align: center;
  font-size: 24px;
}
.index-rst .rst-promotion {
  width: 80vw;
  font-size: 24px;
  color: #999;
  overflow: hidden;
  text-overflow: ellipsis;
  margin: 2.266667vw auto 2.666667vw;
  padding: 0;
  white-space: nowrap;
}
</style>
